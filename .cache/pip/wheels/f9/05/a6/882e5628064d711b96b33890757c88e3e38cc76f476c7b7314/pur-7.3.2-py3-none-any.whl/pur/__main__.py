# -*- coding: utf-8 -*-
"""
    pur.__main__
    ~~~~~~~~~~~~
    Update packages in a requirements.txt file to latest versions.
    :copyright: (c) 2016 Alan Hamlett.
    :license: BSD, see LICENSE for more details.
"""


from .__init__ import pur


if __name__ == '__main__':
    pur()
